<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="ie ie9" lang="en"> <![endif]-->
<html lang="en">

<head>

<!-- Basic Page Needs -->
<meta charset="utf-8">
<title>Trekveda | Baal-Kuari Trail</title>
<meta name="description" content="Baal-Kuari Trail, Local Living in India is an amazing trail to see snowy Himalayas in India. Have a look at the complete details with photos and available dates.">
<meta name="author" content="Amit Kukreti">

<!-- Favicons-->
<link rel="shortcut icon" href="/img/Favicon.png" type="image/x-icon"/>
<link rel="apple-touch-icon" type="image/x-icon" href="/img/apple-touch-icon-57x57-precomposed.png"/>
<link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="/img/apple-touch-icon-72x72-precomposed.png"/>
<link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png"/>
<link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="/img/apple-touch-icon-144x144-precomposed.png"/>

<!-- Mobile Specific Metas -->
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1, user-scalable=no">

<!-- CSS -->
<link href="/css/bootstrap.mins.css" rel="stylesheet">
<link href="/css/nav-style.css" rel="stylesheet">
<link href="/css/ppc.css" rel="stylesheet">
<link href="/fontello/css/fontello.css" rel="stylesheet">
<link href="/css/datepicker.css" rel="stylesheet">
<link rel="stylesheet" href="/js/fancybox/source/jquery.fancybox.css?v=2.1.4">
<link href="/css/weather.css" rel="stylesheet" >
<link href="/css/pospup.css" rel="stylesheet" >
<link rel="stylesheet" href="/css/package-image-slider.css">
<link href="css/card-style.css" rel="stylesheet" >
<!-- SLIDER REVOLUTION -->
<link rel="stylesheet" href="/css/extralayers.css" media="screen" /> 
<link rel="stylesheet" href="/css/navstylechange.css" media="screen" />
<link rel="stylesheet" href="/rs-plugin/css/settings.css" media="screen" />

<!-- Owl Carousel Assets -->
<link href="/css/owl.carousel.css" rel="stylesheet">
<link href="/css/owl.theme.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!--[if lt IE 9]>
<script src="http://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="http://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->

<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '1137130713101122');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=1137130713101122&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code --> 

<script type="text/javascript">
function googleTranslateElementInit() {
new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>


<!-- Global site tag (gtag.js) - Google Ads: 810658167 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-810658167"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'AW-810658167');
</script>


<!--google analytics-->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-105370673-1"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'UA-105370673-1');
</script>
<!--google analytics-->


<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/59a81850c28eca75e461d4ea/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script--> 


<!----onesignal--------->
<link rel="manifest" href="/manifest.json" />
<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
var OneSignal = window.OneSignal || [];
OneSignal.push(function() {
OneSignal.init({
appId: "3c3d9833-1715-45e9-b6b5-58ecfce6215f",
});
});
</script>
<!--end--onesignal--------->

</head>

<body>
<div class="form-container" align="center">
<div id="image">
<img src="/images/slides/baal-kuari-trail-offer-page-banner.jpg" class="img-responsive"/>

</div>

<div id="loginForm" class="contactFrm">
                <form id="enquiry" name="contactform" method="post" action="form-submission-annapurna-base-camp-trek.php">
                    <p class="trek-title">Ball-kuari Trail </p>	
                    <p class="subtitle">Want a detailed PDF - Day wise Itinerary & Quotation</p>	
                    <div class="panel-body">
                        <fieldset>	
                            <input  placeholder="Name " type="text" name="name" maxlength="50" size="30" required/>

                            <input  placeholder="Email "  type="text" name="email" maxlength="80" size="30" required/>

                            <input placeholder="Phone " type="text" name="telephone" maxlength="30" size="30" required/>
                            
                            <input  type="hidden" name="trek_name" value="Ball-kuari Trail "  />

                            <textarea  placeholder="Message (Optional)" name="comments" maxlength="1000" cols="25" rows="6"></textarea>

                            <input type="submit" value="Get Details">
                            <p class="t-c">By clicking the button, you agree to our <a href="term-and-condition.php"><u>Terms of Services</u></a></p>		

                        </fieldset>
                    </div>
                </form>
            </div>		
</div>		
</div>


<div class="container">

<div class="row package">
        <div class="col-md-4">
                <div class="package-price-card">
                        <div class="package-price-card-top">
                                <span>Rs.</span><strong>4,500</strong><small>per person plus 5% GST</small>
                        </div>

                        <hr/>

                        <p><img src="/images/package-icon/calendar.png"/><span>5 Days</span><img src="/images/package-icon/distance.png"/><span style="border:0px">25 Km</span><p>

                        <hr/>

                        <p><img src="/images/package-icon/state.png"/><span style="border:0px">Uttarakhand</span><p>

                        <hr/>

                        <ul style="list-style-type:none">
        <li><img src="/images/package-icon/check.png"/> &nbsp;Best Price Guaranted!</li>
        <li><img src="/images/package-icon/check.png"/> &nbsp;High End Services</li>
        <li><img src="/images/package-icon/check.png"/> &nbsp;Easy Booking & Cancellation</li>
        </ul>

                        <hr/>

                        <a><img src="/images/package-icon/maps-and-flags.png"/><span><b>Start</b> : Parsuli Khal</span><img src="/images/package-icon/maps-and-flags.png"/><span style="border:0px"><b>End</b> : Parsuli Khal</span></a>
                        <hr/>

                </div>


        </div>	


        <div class="col-md-4">
                <div class="package-side-box">
    <div class="package-heading-side">
        <strong>Inclusion/Exclusion</strong>
    </div>
                <span>Inclusion in cost during the trail:</span>
    <ul class="list_ok">
  <li><i class="glyphicon glyphicon-ok" style="color:#228B22"></i> Accommodation </li>
        <li><i class="glyphicon glyphicon-ok" style="color:#228B22"></i> Meals</li>
        <li><i class="glyphicon glyphicon-ok" style="color:#228B22"></i> Gears</li>
                        <li><i class="glyphicon glyphicon-ok" style="color:#228B22"></i> Safety Equipment</li>
                        <li><i class="glyphicon glyphicon-ok" style="color:#228B22"></i> Specialist Guide/Team</li>

    </ul>
                <span>Exclusion in cost during the trail:</span>
                <ul class="list_ok">
        <li><i class="glyphicon glyphicon-remove" style="color:red"></i> Transport to and from the base camp</li>
                        <li><i class="glyphicon glyphicon-remove" style="color:red"></i> Anything separated from considerations</li>
                </ul>

                </div> 


        </div>

        <div class="col-md-4">
        <div class="package-side-box">
                <div class="package-heading-side">
        <strong id="available-dates">Available Dates</strong>
    </div>
                        <div class="panel-group" id="accordion">

                                </div>
        </div>	
        </div>	


</div>

<hr/>
</div>


<div class="container">




</div>

</div>
</div>
<!--End top rated trek-->    





<!--Start Popup-->
<div id="popup1" class="overlay">
<div class="popup">
        <a class="cross" href="javascript: history.go(-1)">&times;</a>

        <div class="contactFrm-popup">


        <form action="request-quote.php" method="post">


        <img style="margin-bottom:15px" src="/img/get-quote-head.png"/>
<input type="text" name="name" placeholder="Enter your name" required="">

<input type="email" name="email" placeholder="Enter your email " required="">

<input type="text" name="phone" placeholder="Enter your phone number" required="">

<textarea name="message" placeholder="Add your message" required=""></textarea>
<input type="submit" name="submit" value="Submit">

<div class="clear"> </div>
</form>
        </div>
</div>

<div class="popup-mobile">
        <a class="cross" href="javascript: history.go(-1)">&times;</a>

        <div class="contactFrm-popup">
        <form action="request-quote.php" method="post">


        <img style="margin-bottom:15px" src="/img/get-quote-head-mobile.png"/>
<input type="text" name="name" placeholder="Enter your name" required="">

<input type="email" name="email" placeholder="Enter your email " required="">

<input type="text" name="phone" placeholder="Enter your phone number" required="">

<textarea name="message" placeholder="Add your message" required=""></textarea>
<input type="submit" name="submit" value="Submit">

<div class="clear"> </div>
        </form>
        </div>
</div>
</div>
<!--End Popup-->

</div><!-- End container -->
<div id="bottom-icon-container"  >
    <div id="bottom-icon-container-child">
        <a id="call_icon" href="tel:9821325154>" > <img  src="/images/call.png" alt="whatsaap" title="whatsaap" style="width: 60px;"></a>
        <a id="Whatsapp_icon" href="https://wa.me/<+919821325154>"><img  src="/images/WhatsApp.png" alt="whatsaap" title="whatsaap" style="width: 60px"></a>
        <a id="message_icon" href="mailto:info@trekveda.com"> <img  src="/images/message.png" alt="whatsaap" title="whatsaap" style="width: 60px;"></a>
        <a id="pdf_download_icon" onclick="document.getElementById('popup_main_id').style.display='block'">  <img  src="/images/pdf.png" alt="whatsaap" title="whatsaap" style="width: 60px"></a>
    </div>  
</div>
<!--      popup-->
<link href="/css/popup_style.css" rel="stylesheet">
<div id="popup_main_id" class="popup_main_class">

<form class="popup-content" id="popup_form_id">
<span onclick="document.getElementById('popup_main_id').style.display='none'" class="close-popup">&times;</span>
<div class="popup-content-container">
<p>Please fill the detail to download itinerary</p>    
<hr>

<input type="text" placeholder="Name" name="Name" >

<input type="tel" placeholder="Contact no" name="contact" required>

<input type="email" placeholder="Enter Email" name="email" >

<input type="text"  name="trek"  value="Baal-Kuari Trail offer" readonly style="display:none">

<center >
    <input class="Sendbtn-popup-detail" id="popup_form_submit_btn" type="submit"  value="Download">
    <button id="quarySubmissionsuccess" style="border: none;background: none;"></button>
</center>
</div>

</form>
</div>
<script>
$(document).ready(function () {
$('#popup_form_id').on('submit', function(event){  
    event.preventDefault();
    $.ajax({
        url: "/popUpquarysubmission.php",
        method: "POST",
        data: new FormData(this),
        contentType: false,
        processData: false,
        success: function (data) {
            $('#popup_main_id').hide();
            window.open('https://trekveda.com//img/trekveda-logo-new2.png')    
        }
    });
});	
});
</script>  

<?php include '../footer.php'; ?>
<!-- Start Header Scrolling --> 



<!-- End Header Scrolling -->
<!-- Weather modal -->
<div class="modal fade" id="weathermodal" tabindex="-1" role="dialog" aria-labelledby="myWeathermodal" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myWeathermodal">Weather Forecast</h4>
    </div>
    <div class="modal-body">
        <div id="weather" class="clearfix">
        </div>
    </div>
</div>
</div>
</div><!-- End Weather modal -->



<!-- OTHER JS -->    
<script src="/js/superfish.js"></script>
<script src="/js/jquery.fitvids.js"></script>
<script src="/js/retina.min.js"></script>
<script src="/js/bootstrap.js"></script>
<script src="/assets/validate.js"></script> 
<script  src="/js/bootstrap-datepicker.js"></script>
<script src="/js/jquery.simpleWeather.min.js"></script>
<script src="/js/jquery.placeholder.js"></script>
<script src="/js/functions.js"></script>
<!-- CAROUSEL -->  
<script src="js/owl.carousel.min.js"></script>
<!-- FANCYBOX -->
<script src="/js/fancybox/source/jquery.fancybox.pack.js?v=2.1.4" type="text/javascript"></script> 
<script src="/js/fancybox/source/helpers/jquery.fancybox-media.js?v=1.0.5" type="text/javascript"></script> 
<script src="/js/fancy_func.js" type="text/javascript"></script> 
<script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit" type="text/javascript"></script>

</body>
</html>