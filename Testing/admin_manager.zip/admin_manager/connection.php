<?php
    $host="162.144.39.63";
    $dbUserName="trekveda_vikas";
    $dbPassword="Admin@123";
    $dbName="trekveda_office";
    $conn=new mysqli($host, $dbUserName, $dbPassword, $dbName);
?>
