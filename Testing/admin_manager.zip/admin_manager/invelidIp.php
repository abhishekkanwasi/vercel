<?php echo '<center>Session Expired! or invelid Session! Please log in again. <br><br>'
. '<button type="Button" class="btn_sale_data"   id="Field_logout_btn"  onclick="window.location.href="logout.php""><a  style="color:black" href="logout.php">Log in</a></button></center>'; ?>
